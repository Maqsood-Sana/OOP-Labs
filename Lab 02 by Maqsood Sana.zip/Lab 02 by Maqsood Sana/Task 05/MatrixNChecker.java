public class MatrixNChecker {

public static void main(String[] args) {
int[][] matrix={
               {1,1,0,0,1},
               {1,0,1,0,1},
               {1,0,0,1,1},
               {1,0,0,0,1}};
        
for(int[] row : matrix){
for(int num : row){
System.out.print(num+" ");
}
System.out.println();
}
        
int rows=matrix.length;
int cols=matrix[0].length;
boolean containsN=false;
        
for (int i=0; i<rows-2; i++){
for (int j=0; j<cols-2; j++){
if(matrix[i][j]==1 && matrix[i + 1][j + 1] == 1 && matrix[i+2][j+2]==1 &&
matrix[i+1][j]==0 && matrix[i][j+1]==1 && matrix[i+2][j+1]==0){
containsN=true;
break;
}
}
}
        
if(containsN) {
System.out.println("The matrix contains the letter 'N'.");
}else{
System.out.println("The matrix does not contain the letter 'N'.");
}
}
}
