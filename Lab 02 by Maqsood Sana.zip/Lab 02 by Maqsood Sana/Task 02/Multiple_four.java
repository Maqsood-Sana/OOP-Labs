import java.util.Scanner;
public class Multiple_four{

public static void main(String[] args){
Scanner src=new Scanner(System.in);
int sum=0;
int arr[] =new int[10];
for(int i=0; i<arr.length; i++){
System.out.print("Enter the Number at "+i+" Index: ");
arr[i]=src.nextInt();
if(arr[i]%4==0){
sum+=arr[i];
}
}
System.out.println("\nThe Sum of multiple of 4 is: "+sum);
}
}