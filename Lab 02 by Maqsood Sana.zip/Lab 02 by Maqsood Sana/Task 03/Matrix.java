import java.util.Scanner;
public class Matrix{

public static void main(String[] args){
Scanner src=new Scanner(System.in);
int sum=0;
System.out.print("Enter the number of rows: ");
int row=src.nextInt();
System.out.print("Enter the number of Col: ");
int col=src.nextInt();

int matrix1[][]=new int[row][col];
int matrix2[][]=new int[row][col];

for(int i=0; i<row; i++){
  for(int j=0; j<col; j++){
System.out.print("Enter the elements of first matrix: ");
matrix1[i][j]=src.nextInt();
}
}
for(int i=0; i<row; i++){
  for(int j=0; j<col; j++){
System.out.print("Enter the elements of Second matrix: ");
matrix2[i][j]=src.nextInt();
}
}
System.out.println("\nSum of Matrices");
for(int i=0; i<row; i++){
 for(int j=0; j<col; j++){
sum=matrix1[i][j]+matrix2[i][j];
System.out.print(sum+"\t");
}
System.out.println();
}
}
}