import java.util.Scanner;

public class check_name{
public static void main(String[] args){
Scanner src=new Scanner(System.in);
String[] name={"Maqsood","Sana","Ali"};
String check;
System.out.print("Enter the Name: ");
check=src.nextLine();
for(int i=0; i<name.length; i++){
if(name[i].equalsIgnoreCase(check)){
System.out.print("Name Ali/ali Found!");
break;
}
else{
System.out.println("Name Ali/ali not Found!");
}




}



}

}