//Lab 01 --->Task -3


import java.util.Scanner;
public class operator{

public static void main(String args[]){
Scanner src=new Scanner(System.in);
System.out.println("\nThis is a long string that is the the "+
                   "concatenation of two shorter strings.");

System.out.println("The first computer was invented about " + 55 + 
                   " years ago.");

System.out.println("8 plus 5 is " + 8 + 5);
System.out.println("8 plus 5 is " +(8 + 5));
System.out.println(8 + 5 +" equals 8 plus 5.");


}
}



import java.util.Scanner;
public class student_database{


public static void main(String args[]){
Scanner src=new Scanner(System.in);
String name="Mr AI";
short age=21;
double gpa=3.15;
char gender='M';
boolean foreigner=false;
int ID=182;

System.out.println("Name: "+name);
System.out.println("Age: "+age);
System.out.println("GPA: "+gpa);
System.out.println("Gender: "+gender);
System.out.println("foreigner: "+foreigner);
System.out.println("Student ID: "+ID);

}
}